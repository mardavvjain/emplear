package dbconn;
import java.sql.*;
public class GetConnection 
{
    private final static String Driver_Name="com.mysql.jdbc.Driver";
    private final static String URL="jdbc:mysql://localhost:3306/emplear";
    private final static String USER = "root";
    private final static String PASS="mysql";
    
    public static Connection getConnect()
    {
            Connection con = null;
            try
            {   
                Class.forName(Driver_Name);
                con = DriverManager.getConnection(URL, USER, PASS);
            }catch(ClassNotFoundException | SQLException e)
            {
                System.out.println("Exception : "+e);
            }
            return con;
    }
}
