package dao;
import java.sql.*;
import dbconn.GetConnection;
import java.util.*;
import dto.Recruiter;
import dto.Candidate;
import java.sql.SQLException;

public class AdminDao 
{
    public int adminLogin(String email,String password) throws SQLException
    {
            int i=0;
            Connection con = GetConnection.getConnect();
            String query = "select * from admin where email=? and password=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next())
                 i=1;
            con.close();
            return i;
    }
    
    public List<Recruiter> getRecruiterList() throws SQLException
    {
        ArrayList<Recruiter> list = new ArrayList<>();
        Connection con = GetConnection.getConnect();
        String query = "select * from recruiterdemo";
        PreparedStatement ps = con.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        while(rs.next())
        {
            Recruiter rt = new Recruiter();
            rt.setName(rs.getString(1));
            rt.setRecruiter(rs.getString(2));
            rt.setEmail(rs.getString(3));
            rt.setPassword(rs.getString(4));
            rt.setContact(rs.getString(5));
            rt.setAddress(rs.getString(6));
            rt.setStatus(rs.getString(7));
            list.add(rt);
        }
        return list;
    }
    
    public int approveRecruiter(String email) throws SQLException
    {
        int i=0;
        Connection con = GetConnection.getConnect();
        String query = "update recruiterdemo set status=? where email=?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1,"Active");
        ps.setString(2,email);
        i=ps.executeUpdate();
        con.close();
        return i;
    }
    
    
    public List<Candidate> getCandidateList() throws SQLException
    {
        ArrayList<Candidate> list = new ArrayList<>();
        Connection con = GetConnection.getConnect();
        String query = "select * from candidate";
        PreparedStatement ps = con.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        while(rs.next())
        {
            
            Candidate rt = new Candidate();
            rt.setFname(rs.getString(1));
            rt.setLname(rs.getString(2));
            rt.setEmail(rs.getString(3));
            rt.setPassword(rs.getString(4));
            rt.setGender(rs.getString(5));
            rt.setDate(rs.getString(6));
            rt.setAddress(rs.getString(7));
            rt.setMobile(rs.getString(8));
            rt.setQualification(rs.getString(9));
            rt.setPercentage(rs.getString(10));
            rt.setExperience(rs.getString(11));
            rt.setStatus(rs.getString(12));
            list.add(rt);
        }
        return list;
    }
    public int approveCandidate(String email) throws SQLException
    {
        int i=0;
        Connection con = GetConnection.getConnect();
        String query = "update candidate set status=? where email=?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1,"Active");
        ps.setString(2,email);
        i=ps.executeUpdate();
        con.close();
        return i;
    }
    
}











