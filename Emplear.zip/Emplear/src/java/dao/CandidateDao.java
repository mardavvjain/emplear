package dao;
import java.sql.*;
import dbconn.GetConnection;
import dto.Candidate;
import dto.AppliedVacancy;
import java.util.*;

public class CandidateDao 
{
    public int addCandidate(Candidate obj) 
    {
        int i=0;
        Connection con = GetConnection.getConnect();
        String query = "insert into candidate(fname,lname,email,password,gender,date,address,mobile,qualification,percentage,experience,status) values(?,?,?,?,?,?,?,?,?,?,?,?)";
       try
       {
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, obj.getFname());
        ps.setString(2, obj.getLname());
        ps.setString(3, obj.getEmail());
        ps.setString(4, obj.getPassword());
        ps.setString(5, obj.getGender());
        ps.setString(6, obj.getDate());
        ps.setString(7, obj.getAddress());
        ps.setString(8, obj.getMobile());
        ps.setString(9, obj.getQualification());
        ps.setString(10, obj.getPercentage());
        ps.setString(11, obj.getExperience());
        ps.setString(12, "Inactive");

        i = ps.executeUpdate();
        con.close();
       }
       catch(Exception e)
       {
           System.out.println("Exception : "+e);
           i=2;
       }
        return i;
    }
        public int candidateLogin(String email,String password) throws SQLException
    {
        int i=0;
        Connection con = GetConnection.getConnect();
        String query= "select * from candidate where email=? and password=? and status=?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, email);
        ps.setString(2, password);
        ps.setString(3, "Active");
         
        ResultSet rs = ps.executeQuery();
        if(rs.next())
            i=1;
        con.close();
        return i;
    }
        public int deleteaccount(String email) throws SQLException
    {
        int i=0;
        Connection con=GetConnection.getConnect();
        String query="delete from candidate where email=?";
        PreparedStatement ps=con.prepareStatement(query);
        ps.setString(1,email);
        i=ps.executeUpdate();
        con.close();
        return i;
    }
        
        public Candidate getinfo(String email) throws SQLException
    {
        Candidate user=new Candidate();
        Connection con=GetConnection.getConnect();
        String query="select * from Candidate where email=?";
        PreparedStatement ps=con.prepareStatement(query);
        ps.setString(1,email);
        ResultSet rs=ps.executeQuery();
    if(rs.next())
    {
        user.setFname(rs.getString(1));
        user.setLname(rs.getString(2));
        user.setEmail(rs.getString(3));
        user.setPassword(rs.getString(4));
        user.setGender(rs.getString(5));
        user.setDate(rs.getString(6));
        user.setAddress(rs.getString(7));
        user.setMobile(rs.getString(8));
        user.setQualification(rs.getString(9));
        user.setPercentage(rs.getString(10));
        user.setExperience(rs.getString(11));
        user.setStatus(rs.getString(12));
    }
    con.close();
    return user;
        
    }
public int updateuser(Candidate user) throws SQLException
    {
        
        Connection con=GetConnection.getConnect();
        String query="update Candidate set fname=?,lname=?,password=?,date=?,address=?,mobile=?,qualification=?,percentage=?,experience=? ,status=? where email=?";
        PreparedStatement ps=con.prepareStatement(query);
        ps.setString(1,user.getFname());
        ps.setString(2,user.getLname());
        ps.setString(3,user.getPassword());
       
        ps.setString(4,user.getDate());
        ps.setString(5,user.getAddress());
        ps.setString(6,user.getMobile());
        ps.setString(7,user.getQualification());
        ps.setString(8,user.getPercentage());
        ps.setString(9,user.getExperience());
        ps.setString(10,user.getStatus());
        ps.setString(11,user.getEmail());
        
       
        int i=ps.executeUpdate();
        con.close();
        return i;
        
    }


public List<AppliedVacancy> getCandidateList(String email) throws SQLException
{
  List<AppliedVacancy> list=new ArrayList<>();
  Connection con=GetConnection.getConnect();
  String query="select * from appliedvacancy where candidateemail=?";
  PreparedStatement ps=con.prepareStatement(query);
  ps.setString(1,email);
  ResultSet rs=ps.executeQuery();
  while(rs.next())
  {
    AppliedVacancy rt=new AppliedVacancy();
    rt.setId(rs.getInt(1));
    rt.setVid(rs.getInt(2));
    rt.setCandidateemail(rs.getString(3));
    rt.setRecruiteremail(rs.getString(4));
    rt.setPost(rs.getString(5));
    rt.setStatus(rs.getString(6));
    list.add(rt);
  }
  return list;
}




}
